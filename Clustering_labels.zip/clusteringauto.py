import sys
import os
os.environ["OMP_NUM_THREADS"] = "3"
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning, module="sklearn")

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.fft import rfft, fftfreq
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN, MeanShift, SpectralClustering, AffinityPropagation, OPTICS, Birch
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from tqdm import tqdm

filenames = ['a000_1','a000_2','a000_3','a000_4','a000_5','a000_6','a000_8','a000_9','a000_10','a001_1','a001_3','a002_1','a002_2','a003_1','a003_2','a004_2','a005_1','a007_2','a009_2','a009_3','a010_1','a010_3','a011_1','a011_3','a012_1','a012_3','a013_1','a013_3','a014_1','a014_1','a014_3','a015_1','a015_2','a015_3','a016_3','a017_1','a017_3','a018_2','a018_3','a020_1','a020_3','a021_1','a021_3','a022_1','a022_3','a023_2','a023_3','a025_1','a025_3','a026_1','a026_3']
for name in tqdm(filenames):
    file_path = 'C:/Users/micha/Downloads/train_dataset_1/' + name + '/data.hdf5'

    if '..' not in sys.path:
        sys.path.append('../')
    from utils import load_data
    data_dict = load_data(file_path, verbose=False)
    size = data_dict['synced/gyro'].shape[0]
    N = size #Chopped to fit time bins
    time_bin_size = 100 #5 seconds pr behavior bin
    num_bins = int(N/time_bin_size) #Giving 67 time bins

    if N == 0:
        ekf_ori = data_dict['pose/ekf_ori']
        tango_ori = data_dict['pose/tango_ori']
        tango_pos = data_dict['pose/tango_pos']
        gyro = data_dict['synced/gyro']
        gyro_uncalib = data_dict['synced/gyro_uncalib']
        acc = data_dict['synced/acce']
        linacc = data_dict['synced/linacce']
        mag = data_dict['synced/magnet']
        num_samples = ekf_ori.shape[0]
        time = data_dict['synced/time']
        rv = data_dict['synced/rv']
        game_rv = data_dict['synced/game_rv']
        diffs = np.diff(time)
        dt = np.mean(diffs)
        q_0 = ekf_ori[0,:]
        
    else:
        ekf_ori = data_dict['pose/ekf_ori'][:N]
        tango_ori = data_dict['pose/tango_ori'][:N]
        tango_pos = data_dict['pose/tango_pos'][:N]
        gyro = data_dict['synced/gyro'][:N]
        gyro_uncalib = data_dict['synced/gyro_uncalib'][:N]
        acc = data_dict['synced/acce'][:N]
        linacc = data_dict['synced/linacce'][:N]
        mag = data_dict['synced/magnet'][:N]
        num_samples = ekf_ori.shape[0]
        time = data_dict['synced/time'][:N]
        rv = data_dict['synced/rv'][:N]
        game_rv = data_dict['synced/game_rv'][:N]
        diffs = np.diff(time)
        dt = np.mean(diffs)
        q_0 = ekf_ori[0,:]

    selected_features = np.concatenate([gyro.T, game_rv.T, rv.T, mag.T]).T #For now I only work with orientation and acceleration
    #, gyro.T, linacc.T, game_rv.T, rv.T, mag.T
    #Preparing the data
    data_unprocessed = np.zeros((selected_features.shape[1], num_bins, time_bin_size))

    for i in range(selected_features.shape[1]):
        for j in range(num_bins):
            data_unprocessed[i,j,:] = selected_features[j*time_bin_size : (j+1)*time_bin_size, i]

    #Computing the relevant features for the time bins
    data_average = np.mean(data_unprocessed, axis=2)
    data_std = np.std(data_unprocessed, axis=2)

    # Concatenate and inspect the data
    data_processed = np.concatenate([data_average, data_std]).T #Missing the FFT components for now

    num_cluster=8

    kmeans = KMeans(n_clusters=num_cluster)
    kmeans_labels = kmeans.fit_predict(data_processed)

    agglomerative = AgglomerativeClustering(n_clusters=num_cluster)
    agglomerative_labels = agglomerative.fit_predict(data_processed)

    birch = Birch(n_clusters=num_cluster)
    birch_labels = birch.fit_predict(data_processed)

    # Create a 2D line plot
    color_map = {0: 'r', 1: 'g', 2: 'b', 3: 'y', 4: 'magenta', 5: 'cyan', 6: 'orange', 7: 'purple', 8: 'brown'}


    fig3, axs = plt.subplots(2,2, figsize=(10, 10))

    for i in range(num_bins-1):
        axs[0,0].plot(tango_pos[i*time_bin_size:(i+1)*time_bin_size,0], tango_pos[i*time_bin_size:(i+1)*time_bin_size,1], color=color_map[kmeans_labels[i]], linewidth=1, linestyle='-')
        axs[0,0].scatter(tango_pos[(i+1)*time_bin_size,0], tango_pos[(i+1)*time_bin_size,1], color='grey', s=10)
    axs[0,0].scatter(tango_pos[0,0],tango_pos[0,1],color='black', s=20)
    axs[0,0].scatter(tango_pos[-1,0],tango_pos[-1,1],color='black', s=20)

    # Set labels and title
    axs[0,0].set_xlabel('X-axis')
    axs[0,0].set_ylabel('Y-axis')
    axs[0,0].set_title('Kmeans Clustering')
    axs[0,0].grid(True)  # Add gridlines

    for i in range(1, num_bins):
        axs[0,1].plot(tango_pos[i*time_bin_size:(i+1)*time_bin_size,0], tango_pos[i*time_bin_size:(i+1)*time_bin_size,1], color=color_map[agglomerative_labels[i]], linewidth=1, linestyle='-')
        axs[0,1].scatter(tango_pos[i*time_bin_size,0], tango_pos[i*time_bin_size,1], color='grey', s=10)
    axs[0,1].scatter(tango_pos[0,0],tango_pos[0,1],color='black', s=20)
    axs[0,1].scatter(tango_pos[-1,0],tango_pos[-1,1],color='black', s=20)

    # Set labels and title
    axs[0,1].set_xlabel('X-axis')
    axs[0,1].set_ylabel('Y-axis')
    axs[0,1].set_title('Agglomerative Clustering')
    axs[0,1].grid(True)  # Add gridlines

    for i in range(1, num_bins):
        axs[1,1].plot(tango_pos[i*time_bin_size:(i+1)*time_bin_size,0], tango_pos[i*time_bin_size:(i+1)*time_bin_size,1], color=color_map[birch_labels[i]], linewidth=1, linestyle='-')
        axs[1,1].scatter(tango_pos[i*time_bin_size,0], tango_pos[i*time_bin_size,1], color='grey', s=10)
    axs[1,1].scatter(tango_pos[0,0],tango_pos[0,1],color='black', s=20)
    axs[1,1].scatter(tango_pos[-1,0],tango_pos[-1,1],color='black', s=20)

    # Set labels and title
    axs[1,1].set_xlabel('X-axis')
    axs[1,1].set_ylabel('Y-axis')
    axs[1,1].set_title('Birch Clustering')
    axs[1,1].grid(True)  # Add gridlines
    plt.savefig(str(name)+'.png', dpi=300)
    # Show the plot
    plt.show()

    kmeans_labels_fullsize = np.repeat(kmeans_labels,time_bin_size)
    agglo_labels_fullsize = np.repeat(agglomerative_labels,time_bin_size)
    birch_labels_fullsize = np.repeat(birch_labels,time_bin_size)
    
    kmeans_labels_fullsize = np.append(kmeans_labels_fullsize,np.zeros(size%time_bin_size))
    agglo_labels_fullsize = np.append(agglo_labels_fullsize,np.zeros(size%time_bin_size))
    birch_labels_fullsize = np.append(birch_labels_fullsize,np.zeros(size%time_bin_size))

    combined_array = np.column_stack((kmeans_labels_fullsize, agglo_labels_fullsize, birch_labels_fullsize))

    # Convert the combined array to a pandas DataFrame
    df = pd.DataFrame(combined_array, columns=['kmeans_labels', 'agglo_labels', 'birch_labels'])

    # Save the DataFrame as a .csv file with indexing included
    df.to_csv(str(name)+'.csv', index=True)